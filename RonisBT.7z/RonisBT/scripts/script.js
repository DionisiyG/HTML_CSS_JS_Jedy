$(document).ready(function () {
    $('.range-slider').slick({
        dots: false,
        arrows: true,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        /*responsive: [
            {
                breakpoint: 321,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: false
                }
            },
        ]*/
    });
    $('.intro-slider').slick({
        dots: true,
        vertical: true,
        arrows: false,
        draggable:true,
        verticalSwiping:true,
        infinite: true,
        autoplay:true,
        autoplaySpeed:2500,
        speed: 800,
        slidesToShow: 1,
        responsive: [
            {
                breakpoint: 1058,
                settings: {
                    draggable:false,
                    verticalSwiping:false,
                }
            },
        ]
    });
    $('form').each(function () {
        $(this).validate({
            rules:{
                email: {
                    required: true,
                    email: true
                }
            },
            messages: {
                email: "Your email address must be in the format of name@domain.com"
            },
            submitHandler: function(form) {
                form.submit();
            }
        });
    });
   /* jQuery.validator.setDefaults({
        debug: true,
        success: "valid"
    });*/
});
